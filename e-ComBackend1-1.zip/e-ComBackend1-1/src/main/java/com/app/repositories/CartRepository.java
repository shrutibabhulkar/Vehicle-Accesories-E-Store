 package com.app.repositories;

import org.springframework.data.repository.CrudRepository;

import com.app.entities.Cart;

public interface CartRepository extends CrudRepository<Cart, Integer>{
	

}
