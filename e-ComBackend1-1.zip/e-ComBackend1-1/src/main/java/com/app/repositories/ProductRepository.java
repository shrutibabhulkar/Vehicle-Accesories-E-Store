package com.app.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.entities.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>{

	@Query("select p from Product p join Category c on p.category=c.id where c.name='SafetyAccessories'")
	List<Product>findByCategorySafetyAccessories();
	
	@Query("select p from Product p join Category c on p.category=c.id where c.name='BodyParts'")
	List<Product>findByCategoryBodyParts();
	
	@Query("select p from Product p join Category c on p.category=c.id where c.name='Batteries'")
	List<Product>findByCategoryBatteries();

}