package com.app.service;

import com.app.dto.PlaceOrder;

public interface IPaymentService {
		Integer getTotalPayment(int customerId);
		
		String placeOrder(PlaceOrder placeOrder) ;
}
