package com.app.service;

import java.util.List;

import com.app.entities.Product;

public interface ICartService {
//	method to add product to cart 
			public String addProductToCart(int customerId , int productId) ;

//	method to get cart product 
			public List<Product> getAllItemsByCart(int customerId) ;
			
//	get total price 
			
			public Integer getTotalPrice(int custmerId) ;

//  delete all items from cart
			public void deleteAllfromCart(Integer id);
			
			public String deleteFromCart(Integer cartId,Integer productId );
			
}
