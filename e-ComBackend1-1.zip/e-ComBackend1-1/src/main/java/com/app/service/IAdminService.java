package com.app.service;

import com.app.dto.Login;
import com.app.entities.User;

public interface IAdminService {

//	For login of a Admin
	 User loginAsAdmin(Login login) ;
}
