package com.app.entities;


public enum Role {
	 VENDOR , admin ;
}
