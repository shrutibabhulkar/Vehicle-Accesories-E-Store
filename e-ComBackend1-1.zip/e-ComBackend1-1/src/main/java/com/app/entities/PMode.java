package com.app.entities;

public enum PMode {
		COD , ONLINE ;
}
